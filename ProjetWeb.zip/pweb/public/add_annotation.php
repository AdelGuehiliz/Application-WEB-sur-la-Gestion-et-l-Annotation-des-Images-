<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Exiger une connexion et gérer la requête AJAX
requireLogin();
header('Content-Type: application/json');

// Vérifier si la requête est de type POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$imageId = isset($_POST['image_id']) ? intval($_POST['image_id']) : 0;
$description = $_POST['description'] ?? '';
$xPosition = isset($_POST['x_position']) ? floatval($_POST['x_position']) : 0;
$yPosition = isset($_POST['y_position']) ? floatval($_POST['y_position']) : 0;
$width = isset($_POST['width']) ? floatval($_POST['width']) : 0;
$height = isset($_POST['height']) ? floatval($_POST['height']) : 0;

// Valider les données saisies
if ($imageId <= 0 || empty($description) || $xPosition < 0 || $yPosition < 0 || $width <= 0 || $height <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid annotation data']);
    exit;
}

// Vérifier si l’image existe et appartient à l’utilisateur actuel

$sql = "SELECT user_id FROM images WHERE id = ?";
$image = getRow($sql, [$imageId], 'i');

if (!$image || $image['user_id'] != getCurrentUserId()) {
    echo json_encode(['success' => false, 'message' => 'You can only annotate your own images']);
    exit;
}

$annotationId = insertData(
    "INSERT INTO annotations (image_id, description, x_position, y_position, width, height) 
     VALUES (?, ?, ?, ?, ?, ?)",
    [$imageId, $description, $xPosition, $yPosition, $width, $height],
    'isdddd'
);

if ($annotationId) {
    echo json_encode(['success' => true, 'annotation_id' => $annotationId]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to save annotation']);
}