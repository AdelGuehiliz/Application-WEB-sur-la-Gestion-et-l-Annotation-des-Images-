
$(document).ready(function () {

    setTimeout(function () {
        $('.flash-message').fadeOut('slow');
    }, 5000);


    $('.annotation-box').hover(
        function () {
            $(this).find('.annotation-tooltip').show();
        },
        function () {
            $(this).find('.annotation-tooltip').hide();
        }
    );


    $('#image-upload').on('change', function () {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                $('#image-preview').attr('src', e.target.result).show();
            }
            reader.readAsDataURL(file);
        }
    });


    $('#is-public').on('change', function () {
        const isChecked = $(this).is(':checked');
        $('#public-status').text(isChecked ? 'Public' : 'Private');
    });
});