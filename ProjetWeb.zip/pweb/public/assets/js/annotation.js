
$(document).ready(function () {
    const image = $('#annotate-image');
    const container = $('.image-container');
    let isSelecting = false;
    let startX, startY;
    let selectionRect = null;
    let imageOffset = null;


    image.on('load', function () {
        imageOffset = image.offset();


        container.addClass('selection-area');


        container.on('mousedown', startSelection);
        $(document).on('mousemove', updateSelection);
        $(document).on('mouseup', endSelection);
    });


    function startSelection(e) {
        if ($(e.target).hasClass('annotation-box') ||
            $(e.target).closest('.annotation-form').length) {
            return;
        }

        isSelecting = true;


        startX = e.pageX - imageOffset.left;
        startY = e.pageY - imageOffset.top;


        selectionRect = $('<div class="selection-rect"></div>');
        container.append(selectionRect);


        selectionRect.css({
            left: startX + 'px',
            top: startY + 'px',
            width: '0',
            height: '0'
        });

        e.preventDefault();
    }


    function updateSelection(e) {
        if (!isSelecting) return;


        const currentX = e.pageX - imageOffset.left;
        const currentY = e.pageY - imageOffset.top;


        const width = Math.abs(currentX - startX);
        const height = Math.abs(currentY - startY);


        const left = Math.min(startX, currentX);
        const top = Math.min(startY, currentY);


        selectionRect.css({
            left: left + 'px',
            top: top + 'px',
            width: width + 'px',
            height: height + 'px'
        });
    }


    function endSelection(e) {
        if (!isSelecting) return;

        isSelecting = false;


        const currentX = e.pageX - imageOffset.left;
        const currentY = e.pageY - imageOffset.top;


        const width = Math.abs(currentX - startX);
        const height = Math.abs(currentY - startY);


        const left = Math.min(startX, currentX);
        const top = Math.min(startY, currentY);


        if (width < 10 || height < 10) {
            selectionRect.remove();
            return;
        }


        showAnnotationForm(left, top, width, height);
    }


    function showAnnotationForm(left, top, width, height) {

        const formLeft = left + width + 10;
        const formTop = top;


        const form = $(`
            <div class="annotation-form" style="left:${formLeft}px; top:${formTop}px;">
                <div class="form-group">
                    <label for="annotation-text">Description</label>
                    <textarea id="annotation-text" placeholder="Describe this area"></textarea>
                </div>
                <button type="button" id="save-annotation" class="btn">Save</button>
                <button type="button" id="cancel-annotation" class="btn btn-secondary">Cancel</button>
                <input type="hidden" id="x-position" value="${left}">
                <input type="hidden" id="y-position" value="${top}">
                <input type="hidden" id="annotation-width" value="${width}">
                <input type="hidden" id="annotation-height" value="${height}">
            </div>
        `);


        container.append(form);


        form.find('#annotation-text').focus();


        form.find('#save-annotation').on('click', function () {
            const description = form.find('#annotation-text').val().trim();

            if (description === '') {
                alert('Please enter a description for this annotation.');
                return;
            }


            const imageId = $('#image-id').val();
            $.ajax({
                url: 'add_annotation.php',
                type: 'POST',
                data: {
                    image_id: imageId,
                    description: description,
                    x_position: left / image.width(),
                    y_position: top / image.height(),
                    width: width / image.width(),
                    height: height / image.height()
                },
                success: function (response) {
                    try {
                        const result = JSON.parse(response);
                        if (result.success) {

                            selectionRect.removeClass('selection-rect');
                            selectionRect.addClass('annotation-box');
                            selectionRect.attr('data-id', result.annotation_id);


                            const tooltip = $(`<div class="annotation-tooltip">${description}</div>`);
                            selectionRect.append(tooltip);


                            const deleteBtn = $(`<span class="delete-annotation" 
                                                  data-id="${result.annotation_id}">&times;</span>`);
                            selectionRect.append(deleteBtn);


                            form.remove();
                            selectionRect = null;


                            attachAnnotationEvents();
                        } else {
                            alert('Error: ' + result.message);
                        }
                    } catch (e) {
                        alert('Error saving annotation.');
                        console.error(e);
                    }
                },
                error: function () {
                    alert('Error saving annotation.');
                }
            });
        });


        form.find('#cancel-annotation').on('click', function () {
            form.remove();
            selectionRect.remove();
            selectionRect = null;
        });
    }


    function attachAnnotationEvents() {
        $('.annotation-box').hover(
            function () {
                $(this).find('.annotation-tooltip').show();
            },
            function () {
                $(this).find('.annotation-tooltip').hide();
            }
        );


        $('.delete-annotation').on('click', function (e) {
            e.stopPropagation();
            const annotationId = $(this).data('id');

            if (confirm('Are you sure you want to delete this annotation?')) {
                deleteAnnotation(annotationId);
            }
        });
    }


    function deleteAnnotation(annotationId) {
        $.ajax({
            url: 'delete_annotation.php',
            type: 'POST',
            data: { annotation_id: annotationId },
            success: function (response) {
                try {
                    const result = JSON.parse(response);
                    if (result.success) {

                        $(`[data-id="${annotationId}"]`).remove();
                    } else {
                        alert('Error: ' + result.message);
                    }
                } catch (e) {
                    alert('Error deleting annotation.');
                    console.error(e);
                }
            },
            error: function () {
                alert('Error deleting annotation.');
            }
        });
    }


    attachAnnotationEvents();
});