<?php
session_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$userId = getCurrentUserId();

// Récupérer les images publiques de l'utilisateur connecté
$images = getRows("SELECT * FROM images WHERE is_public = 1 AND user_id = ? ORDER BY uploaded_at DESC", [$userId]);

include __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="public.css">

<h2>My Public Images</h2>

<?php if (empty($images)): ?>
    <p style="text-align: center;">You have not uploaded any public images yet.</p>
<?php else: ?>
    <div class="gallery">
        <?php foreach ($images as $image): ?>
            <div class="gallery-item">
                <a href="view_image.php?id=<?php echo $image['id']; ?>">
                    <img src="<?php echo htmlspecialchars($image['file_path']); ?>" alt="">
                    <div class="gallery-caption"><?php echo htmlspecialchars($image['description']); ?></div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
