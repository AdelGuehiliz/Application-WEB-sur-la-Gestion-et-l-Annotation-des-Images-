<?php
session_start();
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$userId = getCurrentUserId();
$images = getRows(
    "SELECT * FROM images WHERE user_id = ? AND is_public = 0 ORDER BY uploaded_at DESC",
    [$userId],
    'i'
);

include __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="private.css">

<h2>My Private Images</h2>
<div class="gallery">
    <?php foreach ($images as $image): ?>
        <div class="gallery-item">
            <a href="view_image.php?id=<?php echo $image['id']; ?>">
                <img src="<?php echo htmlspecialchars($image['file_path']); ?>" alt="">
                <div class="gallery-caption"><?php echo htmlspecialchars($image['description']); ?></div>
            </a>
        </div>
    <?php endforeach; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
