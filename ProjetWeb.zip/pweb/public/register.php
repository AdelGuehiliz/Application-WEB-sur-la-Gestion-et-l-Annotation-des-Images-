<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

session_start();

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$errors = [];
$email = '';
$username = '';

// processus d'inscription register
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $username = $_POST['username'] ?? '';
    
    // Valider les informations 
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    }
    
    if (empty($password)) {
        $errors[] = 'Password is required';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters';
    }
    
    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match';
    }
    
    if (empty($username)) {
        $errors[] = 'Username is required';
    } elseif (strlen($username) < 3 || strlen($username) > 20) {
        $errors[] = 'Username must be between 3 and 20 characters';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = 'Username can only contain letters, numbers, and underscores';
    }
    
    if (empty($errors)) {
        $result = registerUser($email, $password, $username);
        
        if ($result['success']) {
            $_SESSION['flash_message'] = 'Registration successful. Please log in.';
            $_SESSION['flash_message_type'] = 'success';
            header('Location: login.php');
            exit;
        } else {
            $errors[] = $result['message'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="register.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

<section class="background">
    <div class="register-container">
        <form method="POST" action="register.php" class="register-box">
            <h2>Register</h2>

            <?php if (!empty($errors)): ?>
                <div class="flash-message error">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="input-box">
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                <label>Email</label>
                <i class='bx bx-envelope'></i>
            </div>

            <div class="input-box">
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                <label>Username</label>
                <i class='bx bx-user'></i>
            </div>

            <div class="input-box">
                <input type="password" id="password" name="password" required>
                <label>Password</label>
                <i class='bx bx-lock'></i>
            </div>

            <div class="input-box">
                <input type="password" id="confirm_password" name="confirm_password" required>
                <label>Confirm Password</label>
                <i class='bx bx-lock-alt'></i>
            </div>

            <button type="submit" class="btn">Register</button>

            <div class="login-link">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </form>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

</body>
</html>
