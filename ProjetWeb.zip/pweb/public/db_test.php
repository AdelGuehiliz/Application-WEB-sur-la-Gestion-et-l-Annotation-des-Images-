<?php
// Activer l'affichage des erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Définir les fichiers requis
$configFile = 'includes/config.php';
$dbFile = 'includes/db.php';

// Vérifier si les fichiers existent avant de les inclure
echo "<h1>Test de connexion à la base de données</h1>";

// Vérifier si le fichier de configuration existe
if (!file_exists($configFile)) {
    die("<p style='color: red;'>Erreur : Fichier de configuration introuvable à l'emplacement : $configFile</p>");
}

// Vérifier si le fichier de la base de données existe
if (!file_exists($dbFile)) {
    die("<p style='color: red;'>Erreur : Fichier DB introuvable à l'emplacement : $dbFile</p>");
}

// Inclure les fichiers
require_once $configFile;
require_once $dbFile;

// Vérifier si la fonction existe
if (!function_exists('getDbConnection')) {
    die("<p style='color: red;'>Erreur : La fonction getDbConnection() n'est pas définie dans db.php</p>");
}

// Tester la connexion
try {
    $conn = getDbConnection();
    
    echo "<p style='color: green;'>Connexion réussie !</p>";
    
    // Vérifier si des tables existent
    $result = $conn->query("SHOW TABLES");
    
    echo "<h2>Tables de la base de données :</h2>";
    echo "<ul>";
    while ($table = $result->fetch_array()) {
        echo "<li>" . $table[0] . "</li>";
    }
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Échec de la connexion : " . $e->getMessage() . "</p>";
    
    echo "<h2>Informations de débogage :</h2>";
    if (defined('DB_HOST')) echo "<p>Hôte : " . DB_HOST . "</p>";
    if (defined('DB_NAME')) echo "<p>Base de données : " . DB_NAME . "</p>";
    if (defined('DB_USER')) echo "<p>Utilisateur : " . DB_USER . "</p>";
}
?>
