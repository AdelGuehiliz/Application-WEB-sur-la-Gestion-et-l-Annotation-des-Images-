<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();


$imageId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($imageId <= 0) {
    header('Location: my_images.php');
    exit;
}

$sql = "SELECT * FROM images WHERE id = ?";
$image = getRow($sql, [$imageId], 'i');


if (!$image || $image['user_id'] != getCurrentUserId()) {
    $_SESSION['flash_message'] = 'You can only annotate your own images';
    $_SESSION['flash_message_type'] = 'error';
    header('Location: my_images.php');
    exit;
}


$sql = "SELECT id, description, x_position, y_position, width, height 
        FROM annotations 
        WHERE image_id = ?";
$annotations = getRows($sql, [$imageId], 'i');

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2>Annotate Image</h2>
        <p><?php echo htmlspecialchars($image['description']); ?></p>
    </div>
    <div class="card-body">
        <p class="annotation-instructions">
            Click and drag on the image to select an area you want to annotate.
        </p>
        
        <div class="image-container">
            <img id="annotate-image" src="<?php echo htmlspecialchars($image['file_path']); ?>" 
                 alt="<?php echo htmlspecialchars($image['description']); ?>">
            
            <?php foreach ($annotations as $annotation): ?>
                <?php
                // Calculate position and size (convert from relative to pixels)
                $left = $annotation['x_position'] * 100;
                $top = $annotation['y_position'] * 100;
                $width = $annotation['width'] * 100;
                $height = $annotation['height'] * 100;
                ?>
                <div class="annotation-box" data-id="<?php echo $annotation['id']; ?>" 
                     style="left: <?php echo $left; ?>%; top: <?php echo $top; ?>%; 
                            width: <?php echo $width; ?>%; height: <?php echo $height; ?>%;">
                    <div class="annotation-tooltip">
                        <?php echo htmlspecialchars($annotation['description']); ?>
                    </div>
                    <span class="delete-annotation" data-id="<?php echo $annotation['id']; ?>">&times;</span>
                </div>
            <?php endforeach; ?>
        </div>
        
        <input type="hidden" id="image-id" value="<?php echo $image['id']; ?>">
        
        <div class="image-actions">
            <a href="view_image.php?id=<?php echo $image['id']; ?>" class="btn">Done</a>
        </div>
    </div>
</div>

<script src="assets/js/annotation.js"></script>

<?php include 'includes/footer.php'; ?>