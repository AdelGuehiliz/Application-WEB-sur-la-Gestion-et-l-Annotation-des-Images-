<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';

$sql = "SELECT i.id, i.description, i.file_path, i.uploaded_at, u.username 
        FROM images i
        JOIN users u ON i.user_id = u.id
        WHERE i.is_public = 1
        ORDER BY i.uploaded_at DESC";
$images = getRows($sql);
include 'includes/header.php'; 
?>
<link rel="stylesheet" href="index.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

<section class="welcome-section">
    <div class="hero">
        <div class="hero-text">
            <h2>Bienvenue sur <span class="brand">AnnotaPic</span></h2>
            <p>Ajoutez des annotations à vos images pour les rendre plus informatives, interactives et faciles à organiser.</p>
            <a class="cta-button" href="upload.php">Commencer maintenant →</a>
        </div>
        <div class="hero-image">
            <img src="img.svg" alt="Image annotation">
        </div>
    </div>

    <div class="features">
        <a href="public.php" class="feature-box">
            🌍
            <h3>Galerie Publique</h3>
            <p>Explorez les images partagées par la communauté.</p>
        </a>
        <a href="private.php" class="feature-box">
            🔒
            <h3>Galerie Privée</h3>
            <p>Accédez à vos propres images en toute confidentialité.</p>
        </a>
        <a href="upload.php" class="feature-box">
            ⬆️
            <h3>Ajouter une Image</h3>
            <p>Commencez l’annotation en important une nouvelle image.</p>
        </a>
    </div>
</section>
