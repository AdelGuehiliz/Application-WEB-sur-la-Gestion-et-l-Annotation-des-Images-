<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

session_start(); 

// Récupérer l'ID de l'image
$imageId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($imageId <= 0) {
    header('Location: index.php');
    exit;
}

$userId = isLoggedIn() ? getCurrentUserId() : 0;

// Récupérer les données de l'image uniquement si elle est publique ou appartient à l'utilisateur actuel

$sql = "SELECT i.*, u.username 
        FROM images i
        JOIN users u ON i.user_id = u.id
        WHERE i.id = ? AND (i.is_public = 1 OR i.user_id = ?)";
$image = getRow($sql, [$imageId, $userId], 'i');

// Vérifier si l'image existe et si l'utilisateur a la permission
if (!$image) {
    $_SESSION['flash_message'] = 'Image not found or you do not have permission to view it';
    $_SESSION['flash_message_type'] = 'error';
    header('Location: index.php');
    exit;
}

$isOwner = ($userId === $image['user_id']);

$sql = "SELECT id, description, x_position, y_position, width, height 
        FROM annotations 
        WHERE image_id = ?";
$annotations = getRows($sql, [$imageId], 'i');

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2><?php echo htmlspecialchars($image['description']); ?></h2>
        <p>
            Uploaded by <?php echo htmlspecialchars($image['username']); ?> on 
            <?php echo date('F j, Y', strtotime($image['uploaded_at'])); ?>
            (<?php echo $image['is_public'] ? 'Public' : 'Private'; ?>)
        </p>
    </div>
    <div class="card-body">
        <div class="image-container">
            <img src="<?php echo htmlspecialchars($image['file_path']); ?>" alt="<?php echo htmlspecialchars($image['description']); ?>">
            
            <?php foreach ($annotations as $annotation): ?>
                <?php
                $left = $annotation['x_position'] * 100;
                $top = $annotation['y_position'] * 100;
                $width = $annotation['width'] * 100;
                $height = $annotation['height'] * 100;
                ?>
                <div class="annotation-box" data-id="<?php echo $annotation['id']; ?>" 
                     style="left: <?php echo $left; ?>%; top: <?php echo $top; ?>%; 
                            width: <?php echo $width; ?>%; height: <?php echo $height; ?>%;">
                    <div class="annotation-tooltip">
                        <?php echo htmlspecialchars($annotation['description']); ?>
                    </div>
                    <?php if ($isOwner): ?>
                        <span class="delete-annotation" data-id="<?php echo $annotation['id']; ?>">&times;</span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="image-actions">
            <?php if ($isOwner): ?>
                <p>
                    <a href="annotate.php?id=<?php echo $image['id']; ?>" class="btn">Add Annotations</a>
                    <a href="delete_image.php?id=<?php echo $image['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this image? This cannot be undone.');">Delete Image</a>
                </p>
            <?php endif; ?>
        </div>
    </div>
</div>
<link rel="stylesheet" href="view_image.css">

<?php include 'includes/footer.php'; ?>
