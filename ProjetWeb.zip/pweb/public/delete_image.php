<?php
// Démarrer la session avant toute sortie
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Exiger que l'utilisateur soit connecté
requireLogin();

// Vérifier si l'ID de l'image est fourni
$imageId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($imageId <= 0) {
    $_SESSION['flash_message'] = 'ID d’image invalide';
    $_SESSION['flash_message_type'] = 'error';
    header('Location: my_images.php');
    exit;
} 

// Vérifier si l'image existe et appartient à l'utilisateur actuel
$sql = "SELECT * FROM images WHERE id = ? AND user_id = ?";
$image = getRow($sql, [$imageId, getCurrentUserId()], 'ii');
if (!$image) {
    $_SESSION['flash_message'] = 'Image introuvable ou vous n’avez pas la permission de la supprimer';
    $_SESSION['flash_message_type'] = 'error';
    header('Location: my_images.php');
    exit;
}

// Préparer correctement le chemin du fichier
$relativePath = $image['file_path'];
// Supprimer les barres obliques au début pour éviter les problèmes de résolution de chemin
$relativePath = ltrim($relativePath, '/');
// Construire le chemin absolu en utilisant les séparateurs de répertoires
$filePath = __DIR__ . DIRECTORY_SEPARATOR . $relativePath;
// Normaliser le chemin pour résoudre les références ../
$filePath = realpath($filePath);

// Fonction de journalisation détaillée avec des informations enrichies
function logDeletionAttempt($imageId, $filePath, $relativePath, $annotationsDeleted, $imageRecordDeleted, $fileDeleted, $errorMessage = null) {
    $logMessage = "Tentative de suppression pour l'image ID : $imageId\n";
    $logMessage .= "Chemin relatif depuis la BDD : $relativePath\n";
    $logMessage .= "Chemin absolu du fichier : $filePath\n";
    $logMessage .= "Annotations supprimées : " . ($annotationsDeleted ? 'Oui' : 'Non') . "\n";
    $logMessage .= "Enregistrement image supprimé : " . ($imageRecordDeleted ? 'Oui' : 'Non') . "\n";
    $logMessage .= "Fichier existe : " . (file_exists($filePath) ? 'Oui' : 'Non') . "\n";
    $logMessage .= "Fichier supprimé : " . ($fileDeleted ? 'Oui' : 'Non') . "\n";
    
    // Informations supplémentaires sur le fichier
    if (file_exists($filePath)) {
        $logMessage .= "Permissions du fichier : " . decoct(fileperms($filePath)) . "\n";
        $logMessage .= "Propriétaire du fichier : " . fileowner($filePath) . "\n";
        $logMessage .= "Fichier modifiable : " . (is_writable($filePath) ? 'Oui' : 'Non') . "\n";
        $logMessage .= "Dossier modifiable : " . (is_writable(dirname($filePath)) ? 'Oui' : 'Non') . "\n";
    }
    
    if ($errorMessage) {
        $logMessage .= "Message d'erreur : $errorMessage\n";
    }
    
    error_log($logMessage);
}

try {
    // Obtenir la connexion à la base de données
    $conn = getDbConnection();
    
    // Supprimer les annotations associées à l'image - créer une fonction personnalisée pour les opérations DELETE
    $annotationsDeleted = false;
    $stmt = $conn->prepare("DELETE FROM annotations WHERE image_id = ?");
    if ($stmt) {
        $stmt->bind_param('i', $imageId);
        $annotationsDeleted = $stmt->execute();
        $stmt->close();
    }
    
    // Supprimer l'enregistrement de l'image dans la base de données
    $imageRecordDeleted = false;
    $stmt = $conn->prepare("DELETE FROM images WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param('i', $imageId);
        $imageRecordDeleted = $stmt->execute();
        $stmt->close();
    }
    
    // Journaliser les résultats des opérations sur la base de données
    error_log("Résultats de suppression dans la base de données - ID image : $imageId");
    error_log("Annotations supprimées : " . ($annotationsDeleted ? 'Oui' : 'Non'));
    error_log("Enregistrement image supprimé : " . ($imageRecordDeleted ? 'Oui' : 'Non'));
    
    // Gérer la suppression du fichier
    $fileDeleted = false;
    $errorMessage = null;
    
    if (file_exists($filePath)) {
        // Vérifier si le fichier est modifiable avant de tenter de le supprimer
        if (is_writable($filePath)) {
            try {
                // Supprimer l'opérateur @ pour voir les erreurs réelles
                $fileDeleted = unlink($filePath);
                
                if (!$fileDeleted) {
                    $errorMessage = "unlink() a retourné false - le fichier n’a pas pu être supprimé";
                }
            } catch (Exception $e) {
                $errorMessage = "Exception lors de unlink : " . $e->getMessage();
            }
        } else {
            $errorMessage = "Le fichier n'est pas modifiable";
        }
    } else {
        // Le fichier n'existe pas - vérifier si le chemin est valide
        $errorMessage = "Le fichier n'existe pas à l’emplacement : $filePath";
        
        // Essayer de trouver le fichier avec une recherche insensible à la casse
        $directory = dirname($filePath);
        $filename = basename($filePath);
        
        if (is_dir($directory)) {
            $files = scandir($directory);
            foreach ($files as $file) {
                if (strtolower($file) === strtolower($filename)) {
                    $errorMessage .= " (Cependant, un fichier similaire a été trouvé : $file)";
                    break;
                }
            }
        }
        
        // Considérer comme supprimé si le fichier n'existe pas
        $fileDeleted = true;
    }
    
    // Journaliser les informations détaillées sur la tentative de suppression
    logDeletionAttempt($imageId, $filePath, $relativePath, $annotationsDeleted, $imageRecordDeleted, $fileDeleted, $errorMessage);
    
    // Vérifier si l’opération principale (suppression en BDD) a réussi
    if ($imageRecordDeleted) {
        // Définir le message approprié selon le résultat de la suppression du fichier
        if ($fileDeleted) {
            $_SESSION['flash_message'] = 'Image supprimée avec succès';
            $_SESSION['flash_message_type'] = 'success';
        } else {
            // Les enregistrements en BDD sont supprimés mais pas le fichier
            $_SESSION['flash_message'] = 'L’enregistrement de l’image a été supprimé, mais le fichier n’a pas pu être supprimé';
            $_SESSION['flash_message_type'] = 'warning';
        }
    } else {
        $_SESSION['flash_message'] = 'Échec de la suppression des enregistrements de l’image dans la base de données';
        $_SESSION['flash_message_type'] = 'error';
    }
} catch (Exception $e) {
    $_SESSION['flash_message'] = 'Une erreur inattendue est survenue';
    $_SESSION['flash_message_type'] = 'error';
    
    // Journaliser l'exception complète
    error_log("Exception lors de la suppression de l’image : " . $e->getMessage() . "\n" . $e->getTraceAsString());
}

// Rediriger vers la page "mes images"
header('Location: my_images.php');
exit;
