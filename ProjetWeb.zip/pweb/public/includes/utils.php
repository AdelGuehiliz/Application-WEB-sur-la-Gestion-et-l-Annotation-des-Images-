<?php
/**
 * Fonctions utilitaires pour l'application
 */

/**
 * Définir un message flash à afficher sur la page suivante
 * 
 * @param string $message Le texte du message
 * @param string $type Type de message (success, error, info)
 */
function setFlashMessage($message, $type = 'info') {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_message_type'] = $type;
}

/**
 * Formater une chaîne de date
 * 
 * @param string $dateString Une chaîne de date
 * @param string $format Format à utiliser (par défaut : 'M j, Y')
 * @return string Date formatée
 */
function formatDate($dateString, $format = 'M j, Y') {
    return date($format, strtotime($dateString));
}

/**
 * Vérifier si un fichier est une image valide
 * 
 * @param string $filePath Chemin vers le fichier
 * @return bool True si le fichier est une image valide, false sinon
 */
function isValidImage($filePath) {
    // Récupérer les infos de l'image
    $imageInfo = @getimagesize($filePath);
    
    // Vérifier si le fichier est une image
    return $imageInfo !== false;
}

/**
 * Générer un nom de fichier aléatoire sécurisé
 * 
 * @param string $originalName Nom de fichier original
 * @param string $extension Extension du fichier
 * @return string Nom de fichier aléatoire sécurisé
 */
function generateSecureFilename($originalName, $extension) {
    return md5(uniqid() . $originalName . time()) . '.' . $extension;
}

/**
 * Tronquer un texte à une longueur spécifiée
 * 
 * @param string $text Texte à tronquer
 * @param int $length Longueur maximale
 * @param string $append Chaîne à ajouter si tronqué
 * @return string Texte tronqué
 */
function truncateText($text, $length = 50, $append = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    
    return substr($text, 0, $length) . $append;
}

/**
 * Assainir une chaîne pour l'affichage
 * 
 * @param string $string Chaîne à assainir
 * @return string Chaîne assainie
 */
function sanitize($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Vérifier si une chaîne contient uniquement des caractères alphanumériques et des underscores
 * 
 * @param string $string Chaîne à vérifier
 * @return bool True si la chaîne est alphanumérique avec underscores, false sinon
 */
function isAlphanumeric($string) {
    return preg_match('/^[a-zA-Z0-9_]+$/', $string);
}
