<?php
require_once 'config.php';

function getDbConnection() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $conn->set_charset("utf8mb4");
    }
    return $conn;
}

function executeQuery($sql, $params = [], $types = '') {
    $conn = getDbConnection();
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    if (!empty($params)) {
        if (empty($types) || strlen($types) !== count($params)) {
            // Si types incorrect ou vide, on crée un type 's' par paramètre
            $types = str_repeat('s', count($params));
        }

        $refs = [];
        foreach ($params as $key => $value) {
            $refs[$key] = &$params[$key];
        }
        array_unshift($refs, $types);
        call_user_func_array([$stmt, 'bind_param'], $refs);
    }

    $stmt->execute();
    return $stmt->get_result();
}

function getRow($sql, $params = [], $types = '') {
    $result = executeQuery($sql, $params, $types);
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

function getRows($sql, $params = [], $types = '') {
    $result = executeQuery($sql, $params, $types);
    $rows = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
    }
    return $rows;
}

function insertData($sql, $params = [], $types = '') {
    $conn = getDbConnection();
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    if (!empty($params)) {
        if (empty($types) || strlen($types) !== count($params)) {
            $types = str_repeat('s', count($params));
        }

        $refs = [];
        foreach ($params as $key => $value) {
            $refs[$key] = &$params[$key];
        }
        array_unshift($refs, $types);
        call_user_func_array([$stmt, 'bind_param'], $refs);
    }

    if ($stmt->execute()) {
        return $conn->insert_id;
    }
    return null;
}
