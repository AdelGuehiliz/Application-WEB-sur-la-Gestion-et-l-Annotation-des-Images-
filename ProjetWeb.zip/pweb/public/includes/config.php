<?php
//  configuration de bdd 
define('DB_HOST', 'db');
define('DB_USER', 'root');
define('DB_PASS', 'root_password');
define('DB_NAME', 'image_annotation_db');

// configuration de site 
define('SITE_URL', 'http://localhost:8080');
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);
