<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Annotation App</title>
    <link rel="stylesheet" href="assets/css/upload.css">
    <link rel="stylesheet" href="header.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <!-- Icônes Lucide -->
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>
    <header class="main-header">
        <div class="container">
            <div class="logo">
                <h1><a href="index.php">AnnotaPic</a></h1>
            </div>
            <nav>
                <input type="checkbox" id="menu-toggle" />
                <label for="menu-toggle" class="menu-icon">&#9776;</label>
                <ul class="nav-links">
                    <li><a href="public.php"><i data-lucide="globe"></i> Public Gallery</a></li>
                    <li><a href="private.php"><i data-lucide="lock"></i> Private Gallery</a></li>
                    <?php if (isLoggedIn()): ?>
                        <li><a href="my_images.php"><i data-lucide="image"></i> My Images</a></li>
                        <li><a href="upload.php"><i data-lucide="upload"></i> Upload Image</a></li>
                        <li><a href="logout.php"><i data-lucide="log-out"></i> Logout (<?php echo htmlspecialchars(getCurrentUsername()); ?>)</a></li>
                    <?php else: ?>
                        <li><a href="login.php"><i data-lucide="log-in"></i> Login</a></li>
                        <li><a href="register.php"><i data-lucide="user-plus"></i> Register</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <script>
        lucide.createIcons();
    </script>

    <main class="container">
        <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="flash-message <?php echo $_SESSION['flash_message_type'] ?? 'info'; ?>">
            <?php 
            echo $_SESSION['flash_message']; 
            unset($_SESSION['flash_message']);
            unset($_SESSION['flash_message_type']);
            ?>
        </div>
        <?php endif; ?>
