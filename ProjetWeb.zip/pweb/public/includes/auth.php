<?php
require_once 'db.php';

/**
 * Enregistrer un nouvel utilisateur
 * 
 * @param string $email Email de l'utilisateur
 * @param string $password Mot de passe de l'utilisateur (sera haché)
 * @param string $username Nom d'utilisateur
 * @return array Résultat avec le statut de succès et un message
 */
function registerUser($email, $password, $username) {
    // Vérifier si l'email existe déjà
    $existingUser = getRow("SELECT id FROM users WHERE email = ?", [$email]);
    if ($existingUser) {
        return ['success' => false, 'message' => 'Email déjà enregistré'];
    }
    
    // Vérifier si le nom d'utilisateur existe déjà
    $existingUsername = getRow("SELECT id FROM users WHERE username = ?", [$username]);
    if ($existingUsername) {
        return ['success' => false, 'message' => 'Nom d’utilisateur déjà pris'];
    }
    
    // Hacher le mot de passe
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Insérer le nouvel utilisateur
    $userId = insertData(
        "INSERT INTO users (email, password, username) VALUES (?, ?, ?)",
        [$email, $hashedPassword, $username]
    );
    
    if ($userId) {
        return ['success' => true, 'user_id' => $userId, 'message' => 'Inscription réussie'];
    } else {
        return ['success' => false, 'message' => 'Échec de l’inscription'];
    }
}

/**
 * Connecter un utilisateur
 * 
 * @param string $email Email de l'utilisateur
 * @param string $password Mot de passe de l'utilisateur
 * @return array Résultat avec le statut de succès et un message
 */
function loginUser($email, $password) {
    $user = getRow("SELECT id, email, username, password FROM users WHERE email = ?", [$email]);
    
    if (!$user) {
        return ['success' => false, 'message' => 'Email ou mot de passe invalide'];
    }
    
    if (password_verify($password, $user['password'])) {
        // Définir les données de session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['username'] = $user['username'];
        
        return ['success' => true, 'user_id' => $user['id'], 'message' => 'Connexion réussie'];
    } else {
        return ['success' => false, 'message' => 'Email ou mot de passe invalide'];
    }
}

/**
 * Vérifie si l'utilisateur est connecté
 * 
 * @return bool True si l'utilisateur est connecté, false sinon
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Obtenir l'ID de l'utilisateur actuel
 * 
 * @return int|null ID de l'utilisateur s'il est connecté, null sinon
 */
function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}

/**
 * Obtenir le nom d'utilisateur actuel
 * 
 * @return string|null Nom d'utilisateur s'il est connecté, null sinon
 */
function getCurrentUsername() {
    return isset($_SESSION['username']) ? $_SESSION['username'] : null;
}

/**
 * Déconnecter l'utilisateur actuel
 */
function logoutUser() {
    // Vérifier si la session est active avant de la détruire
    if (session_status() == PHP_SESSION_ACTIVE) {
        // Supprimer toutes les variables de session
        $_SESSION = [];
        
        // Détruire la session
        session_destroy();
    }
}

/**
 * Exiger que l'utilisateur soit connecté, rediriger vers la page de connexion sinon
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}
