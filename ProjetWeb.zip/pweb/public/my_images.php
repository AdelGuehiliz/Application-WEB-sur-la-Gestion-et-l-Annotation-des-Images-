<?php
session_start();

require_once 'includes/db.php';
require_once 'includes/auth.php';

requireLogin();

// avoir l'image de user connecté
$userId = getCurrentUserId();
$sql = "SELECT id, file_path, description, is_public, uploaded_at 
        FROM images 
        WHERE user_id = ? 
        ORDER BY uploaded_at DESC";
$images = getRows($sql, [$userId], 'i');

include 'includes/header.php';
?>

<link rel="stylesheet" href="my_images.css">

<h2>📸 My Images</h2>

<?php if (empty($images)): ?>
    <div class="card">
        <div class="card-body">
            <p>🚫 Vous n’avez encore aucune image dans votre galerie.</p>
            <p><a href="upload.php" class="btn">📤 Téléversez votre première image</a></p>
        </div>
    </div>
<?php else: ?>
    <p><a href="upload.php" class="btn">➕ Upload New Image</a></p>
    
    <div class="gallery">
        <?php foreach ($images as $image): ?>
            <div class="gallery-item">
                <a href="view_image.php?id=<?php echo $image['id']; ?>">
                    <img src="<?php echo htmlspecialchars($image['file_path']); ?>" alt="<?php echo htmlspecialchars($image['description']); ?>">
                    <div class="gallery-caption">
                        <p><?php echo htmlspecialchars(substr($image['description'], 0, 50)); ?><?php echo strlen($image['description']) > 50 ? '...' : ''; ?></p>
                        <small>
                            <?php echo $image['is_public'] ? '🌍 Public' : '🔒 Private'; ?> • 
                            <?php echo date('M j, Y', strtotime($image['uploaded_at'])); ?>
                        </small>
                    </div>
                </a>
                <div class="gallery-actions">
                    <a href="delete_image.php?id=<?php echo $image['id']; ?>" class="btn-small btn-danger" onclick="return confirm('Are you sure you want to delete this image?');">🗑️ Delete</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
