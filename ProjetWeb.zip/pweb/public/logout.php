<?php
// Start session 
session_start();

require_once 'includes/auth.php';

// Deconnexion logout de user
logoutUser();

$_SESSION['flash_message'] = 'You have been logged out';
$_SESSION['flash_message_type'] = 'info';

header('Location: login.php');
exit;