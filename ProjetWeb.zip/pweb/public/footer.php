<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Footer Page</title>

    <!-- Lien vers ton fichier CSS spécial pour le footer -->
    <link rel="stylesheet" href="footer.css"> 
</head>

<body>

<main>
    <!-- Contenu principal -->
</main>

<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Image Annotation Project</p>

        <div class="contact-info">
            <h4>Contactez-nous</h4>
            <p>Téléphone : <a href="tel:+1234567890">+1 234 567 890</a></p>
            <p>Email : <a href="mailto:contact@example.com">contact@example.com</a></p>
        </div>

        <div class="social-icons">
            <a href="https://www.facebook.com" target="_blank">
                <img src="facebook.png" alt="Facebook">
            </a>
            <a href="https://twitter.com" target="_blank">
                <img src="x.png" alt="X (Twitter)">
            </a>
            <a href="https://www.youtube.com" target="_blank">
                <img src="youtube.png" alt="YouTube">
            </a>
            <a href="https://www.instagram.com" target="_blank">
                <img src="instagram.png" alt="Instagram">
            </a>
            <a href="https://www.linkedin.com" target="_blank">
                <img src="linkedin.png" alt="LinkedIn">
            </a>
        </div>
    </div>
</footer>

<script src="main.js"></script>

</body>
</html>
