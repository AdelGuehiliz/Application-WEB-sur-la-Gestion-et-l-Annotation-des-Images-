<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

// Exiger une connexion et gérer la requête AJAX
requireLogin();
header('Content-Type: application/json');

// Vérifier si la requête est de type POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode de requête invalide']);
    exit;
}

// Récupérer l'ID de l'annotation
$annotationId = isset($_POST['annotation_id']) ? intval($_POST['annotation_id']) : 0;
if ($annotationId <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID d’annotation invalide']);
    exit;
}

// Vérifier si l’annotation existe et appartient à l’image de l’utilisateur actuel
$sql = "SELECT a.id, i.user_id 
        FROM annotations a 
        JOIN images i ON a.image_id = i.id 
        WHERE a.id = ?";
$annotation = getRow($sql, [$annotationId], 'i');

if (!$annotation) {
    echo json_encode(['success' => false, 'message' => 'Annotation introuvable']);
    exit;
}

if ($annotation['user_id'] != getCurrentUserId()) {
    echo json_encode(['success' => false, 'message' => 'Vous ne pouvez supprimer que des annotations de vos propres images']);
    exit;
}

// Supprimer l’annotation
$result = executeQuery("DELETE FROM annotations WHERE id = ?", [$annotationId], 'i');

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Échec de la suppression de l’annotation']);
}
?>
