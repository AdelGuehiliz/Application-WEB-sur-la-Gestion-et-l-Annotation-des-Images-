<?php
session_start();

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$errors = [];
$description = '';
$isPublic = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $description = $_POST['description'] ?? '';
    $isPublic = isset($_POST['is_public']) ? true : false;

    if (empty($description)) {
        $errors[] = 'Description is required';
    }

    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Please select an image to upload';
    } else {
        $file = $_FILES['image'];
        $fileInfo = pathinfo($file['name']);
        $extension = strtolower($fileInfo['extension']);

        if (!in_array($extension, ALLOWED_EXTENSIONS)) {
            $errors[] = 'Invalid file type. Allowed types: ' . implode(', ', ALLOWED_EXTENSIONS);
        }

        if ($file['size'] > MAX_FILE_SIZE) {
            $errors[] = 'File is too large. Max: ' . (MAX_FILE_SIZE / 1024 / 1024) . 'MB';
        }
    }

    if (empty($errors)) {
        if (!file_exists(UPLOAD_DIR)) {
            mkdir(UPLOAD_DIR, 0755, true);
        }

        $filename = md5(uniqid() . $file['name']) . '.' . $extension;
        $filePath = 'assets/uploads/' . $filename;
        $fullPath = UPLOAD_DIR . $filename;

        if (move_uploaded_file($file['tmp_name'], $fullPath)) {
            $userId = getCurrentUserId();
            $isPublicDb = $isPublic ? 1 : 0;

            $imageId = insertData(
                "INSERT INTO images (user_id, file_path, description, is_public) VALUES (?, ?, ?, ?)",
                [$userId, $filePath, $description, $isPublicDb],
                'isss'
            );

            if ($imageId) {
                $_SESSION['flash_message'] = 'Image uploaded successfully';
                $_SESSION['flash_message_type'] = 'success';
                header('Location: view_image.php?id=' . $imageId);
                exit;
            } else {
                $errors[] = 'Failed to save image information';
                unlink($fullPath);
            }
        } else {
            $errors[] = 'Failed to upload image';
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2>Upload Image</h2>
    </div>
    <div class="card-body">
        <?php if (!empty($errors)): ?>
            <div class="flash-message error">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="upload.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="image">Select Image</label>
                <input type="file" name="image" accept=".jpg,.jpeg,.png,.gif" required>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" required><?php echo htmlspecialchars($description); ?></textarea>
            </div>

            <div class="form-group">
                <label>
                    <input type="checkbox" name="is_public" <?php echo $isPublic ? 'checked' : ''; ?>>
                    Make this image public
                </label>
            </div>

            <button type="submit" class="btn">Upload Image</button>
        </form>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
